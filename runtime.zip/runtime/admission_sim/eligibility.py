"""Conservative evaluation of the original RESTRICT sheet's known branches."""
from collections import defaultdict
import math

SCIENCE=['물리학 Ⅰ','화학 Ⅰ','생명과학 Ⅰ','지구과학 Ⅰ',
         '물리학 Ⅱ','화학 Ⅱ','생명과학 Ⅱ','지구과학 Ⅱ']

def catalog(cells):
    by_scheme=defaultdict(list);by_grade=defaultdict(list);by_unit=defaultdict(list)
    for address,entry in cells.items():
        if not address[1:].isdigit():continue
        row=int(address[1:]);col=address[0]
        if row<3:continue
        if col=='B' and isinstance(entry.get('v'),str):by_scheme[entry['v']].append(row)
        if col=='F' and isinstance(entry.get('v'),str):by_grade[entry['v']].append(row)
        if col=='J' and isinstance(entry.get('v'),str):
            major=cells.get(f'K{row}',{}).get('v')
            if isinstance(major,str):by_unit[(entry['v'],major)].append(row)
    return by_scheme,by_grade,by_unit

def _special(row,grades,foreign_present,cells,field):
    formula=cells.get(f'{field}{row}',{}).get('f')
    if not formula:return None
    gr=lambda r:grades.get(r,0)
    # Check the exact formula family before applying the corresponding rule.
    if field=='C' and '응시자격(수학)' in formula and '응시자격(탐구)' in formula:return 'generic'
    if field=='C' and '과탐동일' in formula:return '제외(과탐동일)' if any(gr(a)>0 and gr(b)>0 for a,b in [(20,21),(22,23),(24,25),(26,27)]) else ''
    if field=='G':
        if '제외(영어)' in formula and '제외(한국사)' in formula:
            return '제외(영어)' if gr(18)>=4 else ('제외(한국사)' if gr(19)>=5 else '')
        if '제외(2외누락)' in formula:return '제외(2외누락)' if not foreign_present else ''
        if 'SMALL(' in formula and '제외(등급합)' in formula:
            score=gr(11)+gr(15)+gr(18)+min(gr(r) for r in range(20,37))
            return '' if score<=14 else '제외(등급합)'
        return None
    if field!='L':return None
    if 'VLOOKUP(' in formula:
        # The other conjunct requires a missing foreign-language grade.
        # When one is present the formula is certainly false; otherwise its
        # dynamic RESTRICT!A lookup remains unported.
        return '' if foreign_present else None
    if 'ROUNDDOWN(AVERAGE(' in formula:
        average=sum(gr(r) for r in range(20,37))/17
        return '' if gr(15)+math.floor(average)<=3 else '제외(등급합)'
    if 'LARGE(' in formula and '제외(등급합)' in formula:
        inquiry=sorted((gr(r) for r in range(20,37)),reverse=True)
        sciences=sorted((gr(r) for r in range(20,28)),reverse=True)
        okay=(gr(15)==1 or (sciences[0]==1 and sciences[1]==1) or
              gr(11)+gr(15)+gr(18)+inquiry[1]<=8)
        return '' if okay else '제외(등급합)'
    if '과탐동일' in formula:
        return '제외(과탐동일)' if any(gr(a)>0 and gr(b)>0 for a,b in [(20,21),(22,23),(24,25),(26,27)]) else ''
    if '생화누락' in formula:
        return '제외(생화누락)' if all(gr(r)==0 for r in [22,23,26,27]) else ''
    if '물화누락' in formula:
        return '제외(물화누락)' if all(gr(r)==0 for r in [20,21,26,27]) else ''
    if '생과누락' in formula:
        return '제외(생과누락)' if all(gr(r)==0 for r in [22,23]) else ''
    if '제외(한국사)' in formula and '$E$19<=4' in formula:
        return '' if gr(19)<=4 else '제외(한국사)'
    return None

def evaluate_scheme(engine,scheme,source_rows,grade_rows,grades,foreign_present,cells):
    reasons=[];unchecked=[]
    if scheme not in engine.names:return {'state':'unchecked','label':'결격 미검사','reason':'반영식 없음'}
    if not source_rows:unchecked.append('RESTRICT 반영식 참조 없음')
    col=engine.names.index(scheme)+4
    for row in source_rows:
        result=_special(row,grades,foreign_present,cells,'C')
        if result=='generic':
            try:
                math_ok=float(engine.cell('COMPUTE',64,col)[0] if hasattr(engine.cell('COMPUTE',64,col),'__len__') else engine.cell('COMPUTE',64,col))
                inquiry_ok=float(engine.cell('COMPUTE',65,col)[0] if hasattr(engine.cell('COMPUTE',65,col),'__len__') else engine.cell('COMPUTE',65,col))
                result='' if math_ok*inquiry_ok==1 else '제외(수탐결격)'
            except Exception:result=None
        if result is None:unchecked.append(f'RESTRICT!C{row}')
        elif result:reasons.append(result)
    for row in grade_rows:
        result=_special(row,grades,foreign_present,cells,'G')
        if result is None:unchecked.append(f'RESTRICT!G{row}')
        elif result:reasons.append(result)
    return {'state':'excluded' if reasons else ('unchecked' if unchecked else 'eligible'),
            'label':reasons[0] if reasons else ('결격 미검사' if unchecked else '응시 조건 확인'),
            'reason':', '.join(unchecked) if unchecked else None}

def evaluate_units(units,engine,profile,restrict_cells):
    by_scheme,by_grade,by_unit=catalog(restrict_cells)
    grades={int(r):float(engine.raw[int(r)][0,2]) for r in engine.raw}
    foreign_present=any(grades[r]>0 for r in range(37,46))
    schemes={u['scheme'] for u in units}
    policies={n:evaluate_scheme(engine,n,by_scheme.get(n,[]),by_grade.get(n,[]),grades,foreign_present,restrict_cells) for n in schemes}
    result=[]
    for u in units:
        base=policies[u['scheme']].copy()
        for row in by_unit.get((u['university'],u['major']),[]):
            issue=_special(row,grades,foreign_present,restrict_cells,'L')
            if issue is None:
                if base['state']!='excluded':base={'state':'unchecked','label':'결격 미검사','reason':f'RESTRICT!L{row}'}
            elif issue and base['state']!='excluded':base={'state':'excluded','label':issue,'reason':None}
        result.append(base)
    return result
