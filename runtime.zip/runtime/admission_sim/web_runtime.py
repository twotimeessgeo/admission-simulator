"""Local-only admissions simulator using the recovered workbook runtimes."""
from pathlib import Path
from urllib.parse import urlparse,unquote
import json
import math
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'runtime/source'
PUBLIC_ROOT=ROOT/'runtime/public'
PUBLIC_KEY='public_september_20260929'
sys.path.insert(0,str(SOURCE/'official_results'))
sys.path.insert(0,str(SOURCE/'scoring_engine'))
sys.path.insert(0,str(SOURCE/'september_official_20260929'))
FinalJuneEngine=final_tables=None
from september_official_20260929_runtime import SeptemberOfficialEngine,load_tables as official_tables
from engine import Engine
from runtime import load_tables,table_lookup
from score import encode
from eligibility import evaluate_units
from perf.fast_engine import FastEngine
import ux7_api

def read(p):return json.loads(Path(p).read_text())
def finite(x):return isinstance(x,(int,float)) and math.isfinite(x)
def number(x):return float(x) if finite(x) else None
def compact_number(x):return round(float(x),9) if finite(x) else x

def index_value(score,scores):
    adequate,expected,reach=scores
    if not all(finite(x) for x in [score,adequate,expected,reach]) or not adequate>expected>reach:
        return None
    if score<reach:
        slope=(.5-.2)/(expected-reach)/(.2*.8)
        z=math.log(.2/.8)+(score-reach)*slope
        p=1/(1+math.exp(-max(-100,min(100,z))))
    elif score<expected:p=.2+.3*(score-reach)/(expected-reach)
    elif score<adequate:p=.5+.3*(score-expected)/(adequate-expected)
    else:
        slope=(.8-.5)/(adequate-expected)/(.8*.2)
        z=math.log(.8/.2)+(score-adequate)*slope
        p=1/(1+math.exp(-max(-100,min(100,z))))
    return min(.95,max(.05,p))*100

class PublicSeptemberEngine(SeptemberOfficialEngine):
    """9월 점수식 + 공식 도수로 계산한 기본 변환표준점수."""
    def __init__(self):
        source=PUBLIC_ROOT/'generated/scorer_2027_public'
        self.bundle=read(source/'scoring.json')
        self.names=self.bundle['names']
        self.co=self.bundle['compute']
        self.s2=self.bundle['subject2']
        self.subject_rows=self.bundle['subject_rows']
        self.maps=np.load(source/'maps.npz')['maps']
        self.labels={name:int(row) for row,name in self.bundle['input_labels'].items()}
        self.maximum={name:max(row[2] for row in self.subject_rows if row[1]==name) for name in set(row[1] for row in self.subject_rows)}
        self.maxcol=len(self.names)+3

class Edition:
    def __init__(self,key):
        self.key=key
        source_key='september_official_20260929' if key==PUBLIC_KEY else key
        self.cached=read(HERE/'cache'/(source_key+'_units.json'))
        self.units=self.cached['units']
        self.restrict=read(HERE/'cache'/(source_key+'_restrict.json'))['cells']
        if key=='final_june_20260701':
            self.engine=FinalJuneEngine();grid,curves,names,pop=final_tables()
        elif key==PUBLIC_KEY:
            self.engine=PublicSeptemberEngine()
            with np.load(PUBLIC_ROOT/'generated/quantiles_2027.npz',allow_pickle=False) as model:
                grid=model['grid'].copy()
                curves=np.stack([model['science'],model['humanities']])
                names=[str(x) for x in model['names']]
            public=read(HERE/'data'/f'ux7_{PUBLIC_KEY}.json')
            pop=(public['populations']['science'],public['populations']['humanities'])
            by_id={int(u['i']):u for u in public['units']}
            assert len(by_id)==len(self.units)
            for unit in self.units:
                result=by_id[int(unit['id'])]
                for group,short in [('all','A'),('science','S'),('humanities','H')]:
                    unit['views'][group]['scores']=result['th']
                    unit['views'][group]['percentiles']=result['tp'][short]
                    unit['views'][group]['history']=[]
        elif key=='september_official_20260929':
            self.engine=SeptemberOfficialEngine();grid,curves,names,pop=official_tables()
        else:
            self.engine=Engine('september');grid,curves,names,pop=load_tables('september')
        assert names==self.engine.names
        self.grid=grid;self.curves=curves;self.pop=pop
        self.subjects={}
        for row in self.engine.subject_rows:
            if row[1] in ['수학','수학(미기)','수학(이과)','수학(문과)']:continue
            self.subjects.setdefault(row[1],set()).add(int(row[2]))
        self.subjects={k:sorted(v,reverse=True) for k,v in self.subjects.items()}
        self.scheme_universities={}
        for u in self.units:self.scheme_universities.setdefault(u['scheme'],set()).add(u['university'])
        self.scheme_universities={k:sorted(v) for k,v in self.scheme_universities.items()}

    def metadata(self):
        return {'edition':self.key,'unit_count':len(self.units),'schemes':len(self.engine.names),
                'subjects':self.subjects,'maximum_percentile':float(self.grid[-1]),
                'source_sha256':(read(PUBLIC_ROOT/'audit/build.json')['draft_sha256'] if self.key==PUBLIC_KEY
                                 else self.cached['original_workbook_sha256'])}

    def normalize(self,record):
        if not isinstance(record,dict):raise ValueError('성적을 입력해 주세요.')
        normalized={}
        for name,value in record.items():
            if name not in self.subjects:raise ValueError(str(name)+' 과목을 찾을 수 없습니다.')
            if not isinstance(value,(int,float)) or isinstance(value,bool) or int(value)!=value:
                raise ValueError(name+' 점수는 정수로 입력해 주세요.')
            if int(value) not in self.subjects[name]:raise ValueError(name+' '+str(value)+('등급은' if name in ('영어','한국사') else '점은')+' 이 시험에 없습니다.')
            normalized[name]=int(value)
        required=['국어','영어','한국사']
        for n in required:
            if n not in normalized:raise ValueError(n+' 성적을 입력해 주세요.')
        if sum(n.startswith('수학(') for n in normalized)!=1:raise ValueError('수학 선택과목을 하나만 입력해 주세요.')
        inquiry=[n for n in normalized if n in self.subjects and (n in SCIENCE or n in SOCIAL)]
        if len(inquiry)!=2 or inquiry[0]==inquiry[1]:raise ValueError('서로 다른 탐구 과목 두 개를 입력해 주세요.')
        return normalized

    def evaluate(self,body):
        record=body.get('record')
        if not isinstance(record,dict):raise ValueError('성적을 입력해 주세요.')
        if self.key=='september_20260903' and body.get('saved_source_case') is True and not record:
            # The distributed September workbook was saved with every exam
            # input zero. The source score engine still retains method base
            # points, while undefined scores use the workbook's 0/7 fallback.
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter('ignore',RuntimeWarning)
                scores=self.engine.scores(__import__('numpy').full((1,1),-1),self.engine.names,
                                         include_grade_defaults=True,grade_policy='comparative')[0]
            return {'edition':self.key,'saved_source_case':True,
                    'rows':[{'id':u['id'],'D':'오류(영어국사)',
                             'G':float(scores[self.engine.names.index(u['scheme'])]) if finite(scores[self.engine.names.index(u['scheme'])]) else 0,
                             'H':80 if finite(scores[self.engine.names.index(u['scheme'])]) else 7}
                            for u in self.units]}
        normalized=self.normalize(record)
        engine=self.engine
        compact=body.get('compact') is True
        if compact:
            fast=FastEngine(engine)
            csat,total=fast.scores_both(normalized)
            profile=None
        else:
            profile=encode(engine,[normalized])
            csat=engine.scores(profile,engine.names)[0]
            total=engine.scores(profile,engine.names,include_grade_defaults=True,grade_policy='comparative')[0]
        # Original formulas use grade defaults in the copied workbook. There
        # is no student-provided school-grade input in this MVP.
        eligibility=evaluate_units(self.units,fast if compact else engine,profile,self.restrict)
        rank={};points={};unavailable=[]
        ns,nh=map(float,self.pop)
        for j,name in enumerate(engine.names):
            score=float(total[j]);points[name]={'csat':float(csat[j]),'total':score}
            values=[]
            for g in [0,1]:
                curve=self.curves[g,:,j]
                if not finite(score) or score-.001<float(curve[-1]):values.append(None);continue
                values.append((table_lookup(self.grid,curve,score+.001)+table_lookup(self.grid,curve,score-.001))/2)
            s,h=values
            rank[name]={'science':s,'humanities':h,
                        'all':(ns*s+nh*h)/(ns+nh) if s is not None and h is not None else None}
            if s is None or h is None:unavailable.append(name)
        group=body.get('group','all')
        if group not in ['all','science','humanities']:raise ValueError('누백 기준이 올바르지 않습니다.')
        rows=[];eligibility_counts={'eligible':0,'excluded':0,'unchecked':0}
        for u,restriction in zip(self.units,eligibility):
            scheme=u['scheme'];value=points.get(scheme);view=u['views'][group]
            score=value['total'] if value else None;rank_value=rank.get(scheme,{}).get(group)
            expected=view['scores'][1]
            margin=score-expected if finite(score) and finite(expected) else None
            rank_margin=view['percentiles'][1]-rank_value if finite(view['percentiles'][1]) and finite(rank_value) else None
            index=index_value(score,view['scores'])
            eligibility_counts[restriction['state']]+=1
            if compact:
                rows.append({'id':u['id'],'score':compact_number(score),'line_index':compact_number(index),
                             'eligibility':{'state':restriction['state']}})
            else:
                rows.append({'id':u['id'],'university':u['university'],'major':u['major'],
                             'round':u['round'],'province':u['province'],'city':u['city'],
                             'stream':u['stream'],'scheme':scheme,'choice_rule':u['choice_rule'],
                             'score':score,'csat_score':value['csat'] if value else None,
                             'percentile':rank_value,'thresholds':view['scores'],
                             'threshold_percentiles':view['percentiles'],
                             'score_margin':margin,'percentile_margin':rank_margin,
                             'line_index':index,'eligibility':restriction,
                             'history':view['history']})
        baseline=rank.get('★표점합',{}).get(group)
        schemes=[]
        for name in engine.names:
            item=rank[name][group]
            if compact:
                schemes.append({'name':name,'score':compact_number(points[name]['total']),
                                'percentiles':{key:compact_number(value) for key,value in rank[name].items()}})
            else:
                schemes.append({'name':name,'score':points[name]['total'],'percentile':item,
                                'percentiles':rank[name],
                                'advantage':baseline-item if finite(baseline) and finite(item) else None,
                                'universities':self.scheme_universities.get(name,[])})
        if compact:return {'rows':rows,'schemes':schemes}
        return {'edition':self.key,'group':group,'rows':rows,'schemes':schemes,
                'units':len(rows),'eligibility_counts':eligibility_counts,
                'percentile_unavailable_schemes':len(unavailable),
                'baseline_percentile':baseline,
                'model_note':'기준선 지수는 제작자 표제 20/50/80의 보간 지표이며 검증된 합격확률이 아닙니다.'}

SCIENCE={'물리학 Ⅰ','화학 Ⅰ','생명과학 Ⅰ','지구과학 Ⅰ','물리학 Ⅱ','화학 Ⅱ','생명과학 Ⅱ','지구과학 Ⅱ'}
SOCIAL={'생활과 윤리','윤리와 사상','한국지리','세계지리','동아시아사','세계사','경제','정치와 법','사회·문화'}
class LazyEditions(dict):
    allowed=(PUBLIC_KEY,)
    def __contains__(self,key):return key in self.allowed
    def __getitem__(self,key):
        if key not in self.allowed:raise KeyError(key)
        if not dict.__contains__(self,key):dict.__setitem__(self,key,Edition(key))
        return dict.__getitem__(self,key)
EDITIONS=LazyEditions()



def invoke(route, body_text):
    body=json.loads(body_text)
    key=body.get('edition')
    if key not in EDITIONS:raise ValueError('페이지가 이전 버전입니다. 새로고침해 주세요.')
    if route=='/api/breakdown':
        ed=EDITIONS[key]
        record=ed.normalize(body.get('record'))
        result=ux7_api.breakdown(ed,record,body.get('scheme'),encode)
    elif route=='/api/evaluate':
        result=EDITIONS[key].evaluate(body)
    else:raise ValueError('알 수 없는 요청입니다.')
    return json.dumps(result,ensure_ascii=False,separators=(',',':'),allow_nan=False)
