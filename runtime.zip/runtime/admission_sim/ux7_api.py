"""UX7 read-only helpers: per-scheme score breakdown and static data files.

Uses the same recovered COMPUTE interpreter as /api/evaluate. It only reads
COMPUTE rows 46-73 (area scores, the five summed components and the
reflection rule text) for one scheme; nothing is written back.
"""
from pathlib import Path
import math
import numpy as np

HERE = Path(__file__).resolve().parent
DATA = HERE / 'data'

AREA_ROWS = {'국어': 46, '수학': 47, '영어': 48, '탐구': 51, '탐구1': 52, '탐구2': 53, '한국사': 57, '제2외국어': 58}
COMPONENT_ROWS = {'기본': 59, '필수': 60, '선택': 61, '가중택': 62, '가감': 63}
RULE_ROWS = {'필수': 66, '선택': 67, '가중택': 68, '탐구수': 69, '한국사대체': 72, '외국어대체': 73}


def _num(v):
    v = np.asarray(v).reshape(-1)[0] if np.ndim(v) else v
    if isinstance(v, (str, bytes)) or v is None:
        return None
    try:
        v = float(v)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def _text(v):
    if isinstance(v, str):
        return v
    n = _num(v)
    if n is None:
        return ''
    return str(int(n)) if n == int(n) else str(n)


def _cells(engine, profile, col):
    engine.raw_inputs(profile)
    areas = {k: _num(engine.cell('COMPUTE', r, col)) for k, r in AREA_ROWS.items()}
    comps = {k: _num(engine.cell('COMPUTE', r, col)) for k, r in COMPONENT_ROWS.items()}
    rules = {k: _text(engine.cell('COMPUTE', r, col)) for k, r in RULE_ROWS.items()}
    csat = _num(engine.cell('COMPUTE', 3, col))
    return areas, comps, rules, csat


def breakdown(edition, record, scheme, encode):
    engine = edition.engine
    if scheme not in engine.names:
        raise ValueError('반영식을 찾을 수 없습니다.')
    col = engine.names.index(scheme) + 4
    profile = encode(engine, [record])
    areas, comps, rules, csat = _cells(engine, profile, col)
    total = _num(engine.scores(profile, [scheme], include_grade_defaults=True, grade_policy='comparative')[0][0])
    # Same subjects at their top standard score / grade 1 for the scale of each area.
    top = {}
    for name in record:
        values = edition.subjects[name]
        top[name] = 1 if max(values) <= 9 else max(values)
    top_areas, top_comps, _, top_csat = _cells(engine, encode(engine, [top]), col)
    return {
        'scheme': scheme, 'areas': areas, 'components': comps, 'rules': rules,
        'csat': csat, 'total': total,
        'extra': (total - csat) if total is not None and csat is not None else None,
        'top': {'areas': top_areas, 'components': top_comps, 'csat': top_csat},
    }


def data_file(url_path):
    name = url_path.rsplit('/', 1)[-1]
    if not name.startswith('ux7_') or not name.endswith('.json') or '/' in name or '..' in name:
        return None
    target = (DATA / name).resolve()
    if target.parent != DATA.resolve() or not target.is_file():
        return None
    return target
