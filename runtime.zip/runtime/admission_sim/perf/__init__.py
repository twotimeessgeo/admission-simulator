"""Optional fast calculation path; source runtimes stay unchanged."""
