"""Load the same official final-June percentile values from a binary package."""
from pathlib import Path

import numpy as np


def load_tables():
    path = Path(__file__).resolve().parent / 'final_june_tables.npz'
    with np.load(path) as data:
        return (data['grid'], data['curves'], data['names'].tolist(),
                tuple(data['populations'].tolist()))
