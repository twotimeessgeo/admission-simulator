"""Single-profile scalar interpreter for the existing score formulas.

The source workbook formulas and lookup maps remain authoritative. This path
only avoids NumPy array operations for a one-student request.
"""
from __future__ import annotations

from pathlib import Path
from functools import lru_cache
import math
import operator
import pickle
import re

import numpy as np

from engine import Ref, colname, parse


COMPARISONS = {'=': operator.eq, '<>': operator.ne, '>': operator.gt,
               '<': operator.lt, '>=': operator.ge, '<=': operator.le}
ARITHMETIC = {'+': operator.add, '-': operator.sub, '*': operator.mul}


@lru_cache(None)
def frozen_plan():
    path = Path(__file__).resolve().parent / 'formula_plan.pkl'
    return pickle.loads(path.read_bytes()) if path.is_file() else {}


class FastEngine:
    def __init__(self, source):
        self.source = source
        self.names = source.names
        self.bundle = source.bundle
        self.co = source.co
        self.s2 = source.s2
        self.maps = source.maps
        self.subject_rows = source.subject_rows
        self.labels = source.labels
        self.maximum = source.maximum
        self.lookup = {(row[1], float(row[2])): i for i, row in enumerate(self.subject_rows)}
        self.columns = {name: j + 4 for j, name in enumerate(self.names)}
        self.reference_cache = {}
        self.parsed = frozen_plan()

    def set_record(self, record):
        self.values = {r: [0.0, 0.0, 0.0] for r in range(9, 46)}
        self.mapped = {r: -1 for r in range(9, 46)}
        for name, score in record.items():
            i = self.lookup[(name, float(score))]
            row = self.subject_rows[i]
            r = self.labels[name]
            if self.mapped[r] >= 0:
                raise ValueError('Duplicate subject')
            self.mapped[r] = i
            self.values[r] = [float(row[2]), float(row[4]), float(row[6])]
            if 20 <= r <= 27:
                self.values[r][1] -= r * 1e-9
            if 28 <= r <= 36:
                self.values[r][1] -= r * 1e-8
            if r == 11:
                self.values[r][1] -= r * 1e-7
        self.values[15] = [sum(self.values[r][c] for r in (12, 13, 14)) for c in range(3)]
        self.raw = {r: np.asarray([self.values[r]]) for r in self.values}
        self.cache = {}
        self.visiting = set()

    def ref(self, text, sheet):
        key = (text, sheet)
        if key not in self.reference_cache:
            self.reference_cache[key] = self.source.reference(text, sheet)
        return self.reference_cache[key]

    def cell(self, sheet, r, c):
        key = (sheet, r, c)
        if key in self.cache:
            return self.cache[key]
        if key in self.visiting:
            raise ValueError('Circular formula ' + str(key))
        self.visiting.add(key)
        if sheet == '수능입력':
            if r not in self.values or c not in (3, 4, 5):
                raise ValueError('Unsupported input dependency ' + str(key))
            value = self.values[r][c - 3]
        elif sheet == 'SUBJECT2':
            value = self.s2.get(colname(c) + str(r), 0)
        elif c == 1 and 9 <= r <= 45:
            value = self.bundle['input_labels'].get(str(r), 0)
        elif c == 2 and 9 <= r <= 45:
            value = self.values[r][0]
        elif c == 3 and 9 <= r <= 45:
            label = self.bundle['input_labels'].get(str(r))
            value = self.maximum.get(label, 0)
            if 20 <= r <= 45 and self.values[r][0] <= 0:
                value = 0
        elif c >= 4 and 9 <= r <= 45:
            i = self.mapped[r]
            value = float(self.maps[i, c - 4]) if i >= 0 else 0.0
            if math.isnan(value):
                value = 0.0
        elif r in (4, 5, 6, 7, 8) and c >= 4:
            raise ValueError('Population/grade formula outside score-only engine ' + str(key))
        else:
            item = self.co.get(colname(c) + str(r), {})
            value = self.evaluate(self.parsed.get(item['f']) or parse(item['f']), sheet) if 'f' in item else item.get('v', 0)
            value = self.scalar(value)
        self.visiting.remove(key)
        self.cache[key] = value
        return value

    def scalar(self, value):
        if isinstance(value, Ref):
            if value.r1 != value.r2 or value.c1 != value.c2:
                raise ValueError('Range in scalar position ' + str(value))
            return self.cell(value.sheet, value.r1, value.c1)
        return value

    def flatten(self, value):
        if isinstance(value, Ref):
            return [self.cell(value.sheet, r, c)
                    for r in range(value.r1, value.r2 + 1)
                    for c in range(value.c1, value.c2 + 1)]
        if isinstance(value, list):
            return [v for part in value for v in self.flatten(part)]
        return [value]

    def numeric(self, value):
        value = self.scalar(value)
        if isinstance(value, str):
            return 0.0 if value == '' else math.nan
        return value

    def stack(self, args):
        values = [v for arg in args for v in self.flatten(arg) if not isinstance(v, str)]
        return values or [0.0]

    def evaluate(self, node, sheet='COMPUTE'):
        kind = node[0]
        if kind == 'value':
            return node[1]
        if kind == 'ref':
            return self.ref(node[1], sheet)
        if kind == 'unary':
            value = self.numeric(self.evaluate(node[2], sheet))
            return -value if node[1] == '-' else value
        if kind == 'binary':
            symbol = node[1]
            a = self.evaluate(node[2], sheet)
            b = self.evaluate(node[3], sheet)
            if symbol == ',':
                return [a, b]
            if symbol in COMPARISONS:
                a = self.scalar(a)
                b = self.scalar(b)
                if isinstance(a, str) != isinstance(b, str):
                    return symbol == '<>'
                return COMPARISONS[symbol](a, b)
            a = self.numeric(a)
            b = self.numeric(b)
            if symbol in ARITHMETIC:
                return ARITHMETIC[symbol](a, b)
            if symbol == '/':
                if b == 0:
                    return math.nan if a == 0 else math.copysign(math.inf, a)
                return a / b
            if symbol == '^':
                try:
                    return a ** b
                except (ValueError, OverflowError):
                    return math.nan
            raise ValueError('Unsupported operator ' + symbol)
        name, args = node[1:]
        def ev(i):
            return self.evaluate(args[i], sheet)
        if name == 'IF':
            condition = self.scalar(ev(0))
            return ev(1) if bool(condition) else (ev(2) if len(args) > 2 else False)
        if name == 'IFERROR':
            value = self.scalar(ev(0))
            return value if isinstance(value, str) or math.isfinite(value) else self.scalar(ev(1))
        if name == 'FIND':
            needle, haystack = self.scalar(ev(0)), self.scalar(ev(1))
            if not isinstance(haystack, str):
                return math.nan
            index = haystack.find(needle)
            return index + 1 if index >= 0 else math.nan
        if name in ('SUM', 'MAX', 'MIN', 'LARGE', 'OR', 'AND'):
            values = self.stack([ev(0)] if name == 'LARGE' else [ev(i) for i in range(len(args))])
            if name == 'SUM':
                return sum(values)
            if name == 'MAX':
                return max(values)
            if name == 'MIN':
                return min(values)
            if name == 'OR':
                return any(values)
            if name == 'AND':
                return all(values)
            k = int(self.scalar(ev(1)))
            return sorted(values)[-k]
        if name == 'COUNTIFS':
            if len(args) != 2:
                raise ValueError('COUNTIFS arity')
            criterion = self.scalar(ev(1))
            match = re.fullmatch(r'(>=|<=|<>|>|<|=)(-?\d+(?:\.\d+)?)', criterion)
            if not match:
                raise ValueError('COUNTIFS criterion ' + criterion)
            return sum(COMPARISONS[match[1]](v, float(match[2])) for v in self.stack([ev(0)]))
        if name == 'ROUND':
            value = self.numeric(ev(0))
            digits = int(self.scalar(ev(1)))
            shifted = value * 10 ** digits
            return math.copysign(math.floor(abs(shifted) + .5), shifted) / 10 ** digits
        if name == 'MATCH':
            if len(args) > 2 and self.scalar(ev(2)) != 0:
                raise ValueError('Nonexact MATCH')
            target = self.scalar(ev(0))
            for i, value in enumerate(self.flatten(ev(1))):
                if value == target:
                    return i + 1
            return math.nan
        if name == 'INDEX':
            ref = ev(0)
            r = int(self.scalar(ev(1)))
            c = int(self.scalar(ev(2))) if len(args) > 2 else 1
            return self.cell(ref.sheet, ref.r1 + r - 1, ref.c1 + c - 1)
        if name == 'HLOOKUP':
            target, ref, offset = self.scalar(ev(0)), ev(1), int(self.scalar(ev(2)))
            if len(args) > 3 and self.scalar(ev(3)) is not False:
                raise ValueError('Nonexact HLOOKUP')
            for c in range(ref.c1, ref.c2 + 1):
                if self.cell(ref.sheet, ref.r1, c) == target:
                    return self.cell(ref.sheet, ref.r1 + offset - 1, c)
            return math.nan
        raise ValueError('Unsupported function ' + name)

    def comparative_grade(self, name, score):
        key = {'상지물치': '상지대', '을지간호1': '을지간호', '을지사회1': '을지사회'}.get(name, name)
        spec = self.bundle['comparative_grade_specs'].get(key)
        if spec is None:
            return self.bundle['grade_defaults'].get(name, 0.0)
        if key == '경기자전':
            for cut, value in zip(spec['score_thresholds'], spec['points'][:-1]):
                if score >= cut:
                    return value
            return spec['points'][-1]
        grade = {r: self.values[r][2] for r in (11, 15, 18, 19, *range(20, 37))}
        inquiry = [grade[r] for r in range(20, 37)]
        if key == '상지대':
            best = min([g for g in inquiry if g > 0] or [9])
            return 210 - 10 * sum([grade[r] if grade[r] > 0 else 9 for r in (11, 15, 18)] + [best]) / 4
        points = spec['grade_points']
        def value(g):
            return points.get(str(int(g)), math.nan)
        k, m, e, h = [value(grade[r]) for r in (11, 15, 18, 19)]
        inquiry_points = [value(g) for g in inquiry]
        present = [x for x in inquiry_points if math.isfinite(x)]
        best = max(present) if present else math.nan
        mean = sum(present) / len(present) if present else math.nan
        def fmax(a, b):
            if math.isnan(a):
                return b
            if math.isnan(b):
                return a
            return max(a, b)
        if key == '경희태권':
            return k + e + best
        if key == '김천간호':
            return k + m + e + h + best
        if key == '을지간호':
            return m * 4 + e * 3 + fmax(k, mean) * 3
        if key == '을지사회':
            return k * 3 + e * 4 + fmax(m, mean) * 3
        raise ValueError('Unsupported comparative grade scheme ' + key)

    def scores_both(self, record):
        self.set_record(record)
        csat, total = [], []
        for name in self.names:
            value = float(self.cell('COMPUTE', 3, self.columns[name]))
            extra = self.comparative_grade(name, value) if value != 0 else 0.0
            if not math.isfinite(extra):
                extra = 0.0
            csat.append(value)
            total.append(value + extra)
        return csat, total
