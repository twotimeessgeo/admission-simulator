"""Final-June source-formula runtime; uses original precomputed rank curves.

This is not the unknown statistical generator. Personal grade overrides and
admission eligibility decisions are outside this runtime's scope.
"""
from pathlib import Path
import argparse
import json
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
FINAL=HERE/'final_june_20260701'
sys.path.insert(0,str(HERE.parent/'scoring_engine'))
from engine import Engine,colname
from score import encode
from runtime import table_lookup


def read(path):
    return json.loads(path.read_text())


def prepare():
    subject=read(FINAL/'SUBJECT3_values.json')
    source_compute=read(FINAL/'COMPUTE_cells.json')
    grade=read(FINAL/'내신입력_cells.json')
    names=subject[3][10:]
    assert len(names)==565
    assert names==[source_compute[f'{colname(c)}2']['v'] for c in range(4,569)]
    compute={address:{k:v for k,v in cell.items() if k in ['f','v'] and (k!='v' or 'f' not in cell)} for address,cell in source_compute.items() if isinstance(cell,dict)}
    labels={str(r):source_compute.get(f'A{r}',{}).get('v') for r in range(9,46)}
    # Source F values are used as workbook defaults only for fixed add-ons.
    # The six comparative policies below are recalculated for each profile.
    defaults={grade[f'B{r}']['v']:float(grade.get(f'F{r}',{}).get('v') or 0) for r in range(7,37) if f'B{r}' in grade}
    comparative={}
    for col in range(10,28):
        name=grade.get(f'{colname(col)}5',{}).get('v')
        if name not in ['경기자전','경희태권','김천간호','상지대','을지간호','을지사회']:
            continue
        spec={'formula_cell':f'{colname(col)}6','source_formula':grade[f'{colname(col)}6'].get('f')}
        if name not in ['상지대','경기자전']:
            spec['grade_points']={str(r-6):float(grade[f'{colname(col+2)}{r}']['v']) for r in range(7,16)}
        if name=='경기자전':
            spec['score_thresholds']=[grade[f'{colname(col+1)}{r}']['v'] for r in range(7,11)]
            spec['points']=[grade[f'{colname(col+2)}{r}']['v'] for r in range(7,12)]
        comparative[name]=spec
    assert len(comparative)==6
    prior=read(HERE.parent/'scoring_engine/september_scoring.json')
    for name,spec in comparative.items():
        assert spec['source_formula']==prior['comparative_grade_specs'][name]['source_formula'],name
    s2={f'{colname(c+1)}{r+1}':value for r,row in enumerate(read(FINAL/'SUBJECT2_values.json')) for c,value in enumerate(row) if value is not None}
    metadata=read(FINAL/'metadata.json')
    bundle={'edition':'final_june_20260701','names':names,'subject_rows':[row[:10] for row in subject[4:]],'input_labels':labels,'compute':compute,'subject2':s2,'grade_defaults':defaults,'comparative_grade_specs':comparative,'source_path':metadata['source_path'],'source_sha256':metadata['source_sha256'],'scope':'source scoring formulas and saved contribution values; no generated joint population or eligibility decision; fixed workbook grade defaults retained'}
    (HERE/'final_june_full_scoring.json').write_text(json.dumps(bundle,ensure_ascii=False)+'\n')
    np.savez_compressed(HERE/'final_june_full_maps.npz',maps=np.asarray([row[10:] for row in subject[4:]],float))
    print(json.dumps({'schemes':len(names),'subject_states':len(bundle['subject_rows']),'comparative_policies':len(comparative)},ensure_ascii=False))


class FinalJuneEngine(Engine):
    def __init__(self):
        self.bundle=read(HERE/'final_june_full_scoring.json')
        self.names=self.bundle['names']
        self.co=self.bundle['compute']
        self.s2=self.bundle['subject2']
        self.subject_rows=self.bundle['subject_rows']
        self.maps=np.load(HERE/'final_june_full_maps.npz')['maps']
        self.labels={name:int(row) for row,name in self.bundle['input_labels'].items()}
        self.maximum={name:max(row[2] for row in self.subject_rows if row[1]==name) for name in set(row[1] for row in self.subject_rows)}
        self.maxcol=len(self.names)+3


def load_tables():
    data=read(FINAL/'PERCENTAGE_values.json')
    n=565
    grid=np.asarray([row[0] for row in data[4:]],float)
    values=np.asarray([row[1:] for row in data[4:]],float)
    q=np.stack([values[:,:n],values[:,n:]])
    names=[name.removesuffix(' 이과') for name in data[3][1:1+n]]
    cells=read(FINAL/'SUBJECT1_cells.json')
    return grid,q,names,(cells['D13']['v'],cells['D14']['v'])


def evaluate(records,schemes=None):
    engine=FinalJuneEngine()
    profiles=encode(engine,records)
    schemes=schemes or engine.names
    csat=engine.scores(profiles,schemes)
    total=engine.scores(profiles,schemes,include_grade_defaults=True,grade_policy='comparative')
    grid,q,names,(ns,nh)=load_tables()
    assert names==engine.names
    rows=[]
    for pi in range(len(records)):
        for col,name in enumerate(schemes):
            score=float(total[pi,col]);index=names.index(name)
            if not np.isfinite(score):
                raise ValueError(f'Nonfinite score for profile{pi}, {name}; check required subject inputs')
            if any(score-.001<q[group,-1,index] for group in [0,1]):
                raise ValueError(f'Profile{pi}, {name}: score lies below the stored94.5-percentile range; no extrapolated percentile is supplied')
            science=[table_lookup(grid,q[0,:,index],score+eps) for eps in [.001,-.001]]
            humanities=[table_lookup(grid,q[1,:,index],score+eps) for eps in [.001,-.001]]
            whole=[(ns*s+nh*h)/(ns+nh) for s,h in zip(science,humanities)]
            rows.append({'profile_index':pi,'scheme':name,'csat_score':float(csat[pi,col]),'comparative_grade_score':score-float(csat[pi,col]),'total_score':score,'science_lower_percentile':science[0],'science_upper_percentile':science[1],'science_mid_percentile':sum(science)/2,'humanities_lower_percentile':humanities[0],'humanities_upper_percentile':humanities[1],'humanities_mid_percentile':sum(humanities)/2,'whole_lower_percentile':whole[0],'whole_upper_percentile':whole[1],'whole_mid_percentile':sum(whole)/2})
    return {'edition':'final_june_20260701','table_source':'original PERCENTAGE; statistical generator not implied','populations':{'science':ns,'humanities':nh},'maximum_tabulated_percentile':float(grid[-1]),'below_table_range_policy':'raise rather than extrapolate','personal_grade_override_supported':False,'admission_eligibility_checked':False,'rows':rows}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare',action='store_true')
    parser.add_argument('--input',type=Path)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--schemes',nargs='+')
    args=parser.parse_args()
    if args.prepare:
        prepare()
    elif args.input and args.output:
        records=read(args.input)
        records=records if isinstance(records,list) else [records]
        args.output.write_text(json.dumps(evaluate(records,args.schemes),ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    else:
        parser.error('Use --prepare or --input JSON --output JSON')
