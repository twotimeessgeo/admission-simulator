"""Reproduce the distributed analyzer's score -> percentile lookup.

This reads the original precomputed percentile tables. It is an exact-runtime
reconstruction component, NOT a claim that their statistical generator was
recovered. Score formulas/comparative grades are evaluated independently.
"""
from pathlib import Path
import json,argparse,csv
import numpy as np
from engine import Engine
from score import encode

HERE=Path(__file__).parent;BASE=HERE.parent
def table_lookup(grid,curve,score):
    # Excel MATCH(score, descending scores, -1), with its explicit top guard.
    if score>=curve[0]:return float(grid[0])
    i=int(np.clip(np.searchsorted(-curve,-score,side='right')-1,0,len(grid)-1))
    return float(grid[i])

def load_tables(edition):
    if edition=='june':
        ar=np.load(BASE/'simple_forensics/june_tables.npz');q=ar['Q']
        meta=json.loads((BASE/'simple_forensics/june_meta.json').read_text())
    else:
        ar=np.load(BASE/'reconstruction/tables.npz');q=np.stack([ar['Q'][:,:565],ar['Q'][:,565:]])
        meta=json.loads((BASE/'reconstruction/meta.json').read_text())
    counts=(float(meta['subject1']['D13']['v']),float(meta['subject1']['D14']['v']))
    return ar['grid'],q,meta['names'],counts

def evaluate(edition,records,schemes=None):
    e=Engine(edition);profiles=encode(e,records);schemes=schemes or e.names
    csat=e.scores(profiles,schemes)
    total=e.scores(profiles,schemes,include_grade_defaults=True,grade_policy='comparative')
    p,q,names,(ns,nh)=load_tables(edition)
    rows=[]
    for k in range(len(profiles)):
        for j,name in enumerate(schemes):
            score=float(total[k,j]);ix=names.index(name)
            s=[table_lookup(p,q[0,:,ix],score+eps) for eps in [.001,-.001]]
            h=[table_lookup(p,q[1,:,ix],score+eps) for eps in [.001,-.001]]
            whole=[(ns*sv+nh*hv)/(ns+nh) for sv,hv in zip(s,h)]
            rows.append({'profile_index':k,'scheme':name,'csat_score':float(csat[k,j]),'comparative_grade_score':score-float(csat[k,j]),
                         'total_score':score,'science_lower_percentile':s[0],'science_upper_percentile':s[1],
                         'science_mid_percentile':sum(s)/2,'humanities_lower_percentile':h[0],'humanities_upper_percentile':h[1],
                         'humanities_mid_percentile':sum(h)/2,'whole_lower_percentile':whole[0],'whole_upper_percentile':whole[1],
                         'whole_mid_percentile':sum(whole)/2})
    return {'edition':edition,'table_source':'original precomputed PERCENTAGE; statistical generator not implied',
            'populations':{'science':ns,'humanities':nh},'maximum_tabulated_percentile':float(p[-1]),
            'whole_percentile_status':'source-confirmed weighted combination' if edition=='september' else 'September weighted-combination rule applied to June as an extension; June has no whole-group result sheet',
            'personal_grade_override_supported':False,'rows':rows}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--edition',choices=['june','september'],required=True)
    p.add_argument('--input',required=True);p.add_argument('--output',required=True);p.add_argument('--schemes',nargs='+');a=p.parse_args()
    records=json.loads(Path(a.input).read_text());records=records if isinstance(records,list) else [records]
    result=evaluate(a.edition,records,a.schemes);Path(a.output).write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
    print(json.dumps({'profiles':len(records),'schemes':len(result['rows'])//len(records),'output':a.output},ensure_ascii=False))
