"""Evaluate the source COMPUTE score formulas over artificial candidate batches.

This implements a restricted Excel expression interpreter, never Python eval.
It does not read PERCENTAGE or infer any student's population weight.
Supported profile inputs are SUBJECT3 state indices, with -1 for absence.
"""
from pathlib import Path
from dataclasses import dataclass
from functools import lru_cache
import json,re
import numpy as np
from openpyxl.formula import Tokenizer

HERE=Path(__file__).parent

def colnum(s):
    n=0
    for c in s:n=n*26+ord(c)-64
    return n

def colname(n):
    s=''
    while n:n,i=divmod(n-1,26);s=chr(65+i)+s
    return s

@lru_cache(None)
def parse(formula):
    tokens=[t for t in Tokenizer('='+formula).items if t.type!='WHITE-SPACE'];pos=0
    bp={',':1,'=':2,'<>':2,'>':2,'<':2,'>=':2,'<=':2,'&':3,'+':4,'-':4,'*':5,'/':5,'^':6}
    def expression(minimum=0):
        nonlocal pos
        t=tokens[pos];pos+=1
        if t.type=='OPERATOR-PREFIX':a=('unary',t.value,expression(6))
        elif t.type=='OPERAND':
            if t.subtype=='NUMBER':a=('value',float(t.value))
            elif t.subtype=='TEXT':a=('value',t.value[1:-1].replace('""','"'))
            elif t.subtype=='LOGICAL':a=('value',t.value=='TRUE')
            elif t.subtype=='ERROR':a=('value',np.nan)
            elif t.subtype=='RANGE':a=('ref',t.value)
            else:raise ValueError(('operand',t.value))
        elif t.type=='FUNC' and t.subtype=='OPEN':
            args=[]
            while not (tokens[pos].type=='FUNC' and tokens[pos].subtype=='CLOSE'):
                args.append(expression())
                if tokens[pos].type=='SEP':pos+=1
                else:break
            assert tokens[pos].subtype=='CLOSE',(formula,pos);pos+=1
            a=('call',t.value[:-1],tuple(args))
        elif t.type=='PAREN' and t.subtype=='OPEN':
            a=expression();assert tokens[pos].type=='PAREN' and tokens[pos].subtype=='CLOSE';pos+=1
        else:raise ValueError(('prefix',formula,t.value,t.type))
        while pos<len(tokens):
            t=tokens[pos]
            if t.type=='OPERATOR-POSTFIX':
                pos+=1;a=('binary','/',a,('value',100.0));continue
            if t.type!='OPERATOR-INFIX' or bp.get(t.value,-1)<minimum:break
            pos+=1;operator=t.value;b=expression(bp[operator]+1);a=('binary',operator,a,b)
        return a
    result=expression();assert pos==len(tokens),(formula,pos,tokens[pos].value)
    return result

@dataclass(frozen=True)
class Ref:
    sheet:str
    r1:int
    c1:int
    r2:int
    c2:int

class Engine:
    def __init__(self,edition):
        self.bundle=json.loads((HERE/f'{edition}_scoring.json').read_text())
        self.names=self.bundle['names'];self.co=self.bundle['compute'];self.s2=self.bundle['subject2']
        self.subject_rows=self.bundle['subject_rows'];self.maps=np.load(HERE/f'{edition}_maps.npz')['maps']
        self.labels={name:int(r) for r,name in self.bundle['input_labels'].items()}
        self.maximum={name:max(v[2] for v in self.subject_rows if v[1]==name) for name in set(v[1] for v in self.subject_rows)}
        self.maxcol=len(self.names)+3

    def reference(self,text,sheet):
        text=text.replace('$','')
        if '!' in text:sheet,text=text.rsplit('!',1);sheet=sheet.strip("'").replace("''", "'")
        if sheet not in ['COMPUTE','수능입력','SUBJECT2']:raise ValueError('Unapproved sheet '+sheet)
        ends=text.split(':');ends=ends if len(ends)==2 else ends*2
        def point(s,second):
            if s.isdigit():return int(s),(self.maxcol if second else 1)
            m=re.fullmatch(r'([A-Z]+)(\d+)',s)
            if not m:raise ValueError('Unsupported reference '+text)
            return int(m[2]),colnum(m[1])
        r1,c1=point(ends[0],False);r2,c2=point(ends[1],True)
        return Ref(sheet,r1,c1,r2,c2)

    def raw_inputs(self,profiles):
        self.n=len(profiles);raw={r:np.zeros((self.n,3)) for r in range(9,46)}
        mapped={r:np.full(self.n,-1,dtype=int) for r in range(9,46)}
        for k in range(profiles.shape[1]):
            ids=profiles[:,k]
            for i in np.unique(ids[ids>=0]):
                item=self.subject_rows[i];name=item[1]
                if name not in self.labels:raise ValueError('No input row for '+name)
                r=self.labels[name];mask=ids==i
                if np.any(mapped[r][mask]>=0):raise ValueError('Duplicate subject')
                # Input C=standardized score/grade, D=reported percentile, E=reported grade.
                raw[r][mask]=[item[2],item[4],item[6]];mapped[r][mask]=i
                if 20<=r<=27:raw[r][mask,1]-=r*1e-9
                if 28<=r<=36:raw[r][mask,1]-=r*1e-8
                if r==11:raw[r][mask,1]-=r*1e-7
        raw[15]=raw[12]+raw[13]+raw[14]
        self.raw=raw;self.mapped=mapped;self.cache={};self.visiting=set()

    def cell(self,sheet,r,c):
        key=sheet,r,c
        if key in self.cache:return self.cache[key]
        if key in self.visiting:raise ValueError('Circular formula '+str(key))
        self.visiting.add(key)
        if sheet=='수능입력':
            if r not in self.raw or c not in [3,4,5]:raise ValueError('Unsupported input dependency '+str(key))
            v=self.raw[r][:,c-3]
        elif sheet=='SUBJECT2':v=self.s2.get(colname(c)+str(r),0)
        elif c==1 and 9<=r<=45:v=self.bundle['input_labels'].get(str(r),0)
        elif c==2 and 9<=r<=45:v=self.raw[r][:,0]
        elif c==3 and 9<=r<=45:
            label=self.bundle['input_labels'].get(str(r));v=self.maximum.get(label,0)
            if 20<=r<=45:v=np.where(self.raw[r][:,0]>0,v,0)
        elif c>=4 and 9<=r<=45:
            ids=self.mapped[r];v=np.zeros(self.n);mask=ids>=0
            v[mask]=self.maps[ids[mask],c-4]
            # IFERROR on the source lookup returns zero for absent/unmapped values.
            v=np.nan_to_num(v,nan=0.0)
        elif r in [4,5,6,7,8] and c>=4:
            raise ValueError('Population/grade formula outside score-only engine '+str(key))
        else:
            d=self.co.get(colname(c)+str(r),{})
            v=self.evaluate(parse(d['f']),sheet) if 'f' in d else d.get('v',0)
            v=self.scalar(v)
        self.visiting.remove(key);self.cache[key]=v
        return v

    def scalar(self,v):
        if isinstance(v,Ref):
            if v.r1!=v.r2 or v.c1!=v.c2:raise ValueError('Range in scalar position '+str(v))
            return self.cell(v.sheet,v.r1,v.c1)
        return v

    def flatten(self,v):
        if isinstance(v,Ref):
            return [self.cell(v.sheet,r,c) for r in range(v.r1,v.r2+1) for c in range(v.c1,v.c2+1)]
        if isinstance(v,list):return [x for a in v for x in self.flatten(a)]
        return [v]

    def numeric(self,v):
        v=self.scalar(v)
        if isinstance(v,str):return 0.0 if v=='' else np.nan
        return v

    def stack(self,args):
        vals=[v for arg in args for v in self.flatten(arg) if not isinstance(v,str)]
        if not vals:return np.zeros((1,self.n))
        return np.stack([np.broadcast_to(v,(self.n,)) for v in vals])

    def evaluate(self,node,sheet='COMPUTE'):
        op=node[0]
        if op=='value':return node[1]
        if op=='ref':return self.reference(node[1],sheet)
        if op=='unary':
            a=self.numeric(self.evaluate(node[2],sheet));return -a if node[1]=='-' else a
        if op=='binary':
            symbol=node[1];a=self.evaluate(node[2],sheet);b=self.evaluate(node[3],sheet)
            if symbol==',':return [a,b]
            if symbol in ['=','<>','>','<','>=','<=']:
                a=self.scalar(a);b=self.scalar(b)
                if isinstance(a,str)!=isinstance(b,str):return symbol=='<>'
                return {'=':np.equal,'<>':np.not_equal,'>':np.greater,'<':np.less,'>=':np.greater_equal,'<=':np.less_equal}[symbol](a,b)
            a=self.numeric(a);b=self.numeric(b)
            with np.errstate(all='ignore'):
                return {'+':np.add,'-':np.subtract,'*':np.multiply,'/':np.divide,'^':np.power}[symbol](a,b)
        name,args=node[1:]
        def ev(i):return self.evaluate(args[i],sheet)
        if name=='IF':
            cond=self.scalar(ev(0))
            if np.ndim(cond)==0:return ev(1) if bool(cond) else (ev(2) if len(args)>2 else False)
            a=self.scalar(ev(1));b=self.scalar(ev(2)) if len(args)>2 else False
            if isinstance(a,str) or isinstance(b,str):
                # Only numeric placeholders occur in vector branches of these sheets.
                a=self.numeric(a);b=self.numeric(b)
            return np.where(cond,a,b)
        if name=='IFERROR':
            a=self.scalar(ev(0))
            if isinstance(a,str):return a
            return np.where(np.isfinite(a),a,self.scalar(ev(1)))
        if name=='FIND':
            needle=self.scalar(ev(0));haystack=self.scalar(ev(1))
            if not isinstance(haystack,str):return np.nan
            idx=haystack.find(needle);return idx+1 if idx>=0 else np.nan
        if name in ['SUM','MAX','MIN','LARGE','OR','AND']:
            a=self.stack([ev(0)] if name=='LARGE' else [ev(i) for i in range(len(args))])
            if name=='SUM':return np.sum(a,axis=0)
            if name=='MAX':return np.max(a,axis=0)
            if name=='MIN':return np.min(a,axis=0)
            if name=='OR':return np.any(a,axis=0)
            if name=='AND':return np.all(a,axis=0)
            k=int(self.scalar(ev(1)));return np.sort(a,axis=0)[-k]
        if name=='COUNTIFS':
            if len(args)!=2:raise ValueError('COUNTIFS arity')
            crit=self.scalar(ev(1));m=re.fullmatch(r'(>=|<=|<>|>|<|=)(-?\d+(?:\.\d+)?)',crit)
            if not m:raise ValueError('COUNTIFS criterion '+crit)
            a=self.stack([ev(0)]);fun={'>':np.greater,'<':np.less,'>=':np.greater_equal,'<=':np.less_equal,'=':np.equal,'<>':np.not_equal}[m[1]]
            return np.sum(fun(a,float(m[2])),axis=0)
        if name=='ROUND':
            a=self.numeric(ev(0));n=int(self.scalar(ev(1)));v=a*10**n
            return np.sign(v)*np.floor(abs(v)+.5)/10**n
        if name=='MATCH':
            if len(args)>2 and self.scalar(ev(2))!=0:raise ValueError('Nonexact MATCH')
            target=self.scalar(ev(0));v=self.flatten(ev(1))
            for i,x in enumerate(v):
                if np.ndim(x)==0 and x==target:return i+1
            return np.nan
        if name=='INDEX':
            ref=ev(0);r=int(self.scalar(ev(1)));c=int(self.scalar(ev(2))) if len(args)>2 else 1
            return self.cell(ref.sheet,ref.r1+r-1,ref.c1+c-1)
        if name=='HLOOKUP':
            target=self.scalar(ev(0));ref=ev(1);offset=int(self.scalar(ev(2)))
            if len(args)>3 and self.scalar(ev(3)) is not False:raise ValueError('Nonexact HLOOKUP')
            for c in range(ref.c1,ref.c2+1):
                x=self.cell(ref.sheet,ref.r1,c)
                if np.ndim(x)==0 and x==target:return self.cell(ref.sheet,ref.r1+offset-1,c)
            return np.nan
        raise ValueError('Unsupported function '+name)

    def comparative_grade(self,name,csat_score):
        key={'상지물치':'상지대','을지간호1':'을지간호','을지사회1':'을지사회'}.get(name,name)
        spec=self.bundle['comparative_grade_specs'].get(key)
        if spec is None:return np.full(self.n,self.bundle['grade_defaults'].get(name,0.0))
        if key=='경기자전':
            result=np.full(self.n,spec['points'][-1],float)
            for cut,value in reversed(list(zip(spec['score_thresholds'],spec['points'][:-1]))):
                result=np.where(csat_score>=cut,value,result)
            return result
        grades={r:self.raw[r][:,2] for r in [11,15,18,19]+list(range(20,37))}
        inquiry=np.stack([grades[r] for r in range(20,37)])
        if key=='상지대':
            iq=np.min(np.where(inquiry>0,inquiry,9),axis=0)
            return 210-10*np.mean(np.stack([np.where(grades[r]>0,grades[r],9) for r in [11,15,18]]+[iq]),axis=0)
        def points(grade):
            result=np.full(grade.shape,np.nan)
            for g,value in spec['grade_points'].items():result=np.where(grade==int(g),value,result)
            return result
        k,m,e,h=[points(grades[r]) for r in [11,15,18,19]];ip=points(inquiry)
        with np.errstate(all='ignore'):
            best=np.nanmax(ip,axis=0);mean=np.nanmean(ip,axis=0)
        if key=='경희태권':return k+e+best
        if key=='김천간호':return k+m+e+h+best
        if key=='을지간호':return m*4+e*3+np.fmax(k,mean)*3
        if key=='을지사회':return k*3+e*4+np.fmax(m,mean)*3
        raise ValueError('Unsupported comparative grade scheme '+key)

    def scores(self,profiles,names=None,include_grade_defaults=False,grade_policy='cached'):
        self.raw_inputs(np.asarray(profiles,dtype=int));names=self.names if names is None else names
        result=[]
        for name in names:
            c=self.names.index(name)+4
            try:v=self.cell('COMPUTE',3,c)
            except Exception as err:raise RuntimeError(name+' ('+colname(c)+'): '+str(err)) from err
            v=np.broadcast_to(v,(self.n,)).copy()
            if include_grade_defaults:
                if grade_policy=='cached':v+=self.bundle['grade_defaults'].get(name,0)
                elif grade_policy=='comparative':v+=np.where(v==0,0,np.nan_to_num(self.comparative_grade(name,v),nan=0.0))
                else:raise ValueError('Unknown grade policy')
            result.append(v)
            # Bound memory for large profile batches, retaining only cross-scheme dependencies.
            self.cache={k:v for k,v in self.cache.items() if k[0]!='COMPUTE' or k[2]<4 or k[1] in [2,3]}
        return np.stack(result,axis=1)
