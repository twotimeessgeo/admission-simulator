"""Score explicit subject selections with the recovered source formulas."""
import argparse,json,unicodedata
from pathlib import Path
import numpy as np
from engine import Engine

def canonical(s):return ''.join(unicodedata.normalize('NFKC',s).split())

def encode(engine,records):
    names={canonical(r[1]):r[1] for r in engine.subject_rows}
    lookup={(r[1],float(r[2])):i for i,r in enumerate(engine.subject_rows)}
    encoded=[]
    for record in records:
        ids=[];seen=set();math_count=0
        for name,value in record.items():
            if value is None:continue
            name=names.get(canonical(name),name)
            if name in ['수학','수학(미기)','수학(이과)','수학(문과)']:
                raise ValueError('Select 미적, 기하 or 확통 for a student profile')
            if name in seen:raise ValueError('Duplicate normalized subject '+name)
            seen.add(name);math_count+=name.startswith('수학(')
            if (name,float(value)) not in lookup:raise ValueError('Unknown subject/score in this edition: '+str((name,value)))
            ids.append(lookup[(name,float(value))])
        if math_count>1:raise ValueError('A profile cannot select multiple mathematics choices')
        encoded.append(ids)
    if not encoded:raise ValueError('No profiles')
    width=max(map(len,encoded));return np.array([ids+[-1]*(width-len(ids)) for ids in encoded],dtype=int)

def main():
    p=argparse.ArgumentParser();p.add_argument('--edition',choices=['june','september'],required=True)
    p.add_argument('--input',required=True);p.add_argument('--output',required=True)
    p.add_argument('--schemes',nargs='+');p.add_argument('--include-grade-defaults','--include-comparative-grade',action='store_true')
    p.add_argument('--grade-policy',choices=['comparative','cached'],default='comparative');args=p.parse_args()
    records=json.loads(Path(args.input).read_text());records=[records] if isinstance(records,dict) else records
    engine=Engine(args.edition);profiles=encode(engine,records);names=args.schemes or engine.names
    scores=engine.scores(profiles,names,include_grade_defaults=args.include_grade_defaults,grade_policy=args.grade_policy)
    result={'edition':args.edition,'scope':'Source CSAT scoring formulas; no population ranking or admission eligibility decision',
            'grade_defaults_added':args.include_grade_defaults,'grade_policy':args.grade_policy if args.include_grade_defaults else None,'schemes':names,
            'profiles':[{'input':record,'scores':[float(v) if np.isfinite(v) else None for v in row]}
                        for record,row in zip(records,scores)]}
    Path(args.output).write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
    print(json.dumps({'profiles':len(profiles),'schemes':len(names),'nonfinite_scores':int((~np.isfinite(scores)).sum()),'output':args.output},ensure_ascii=False))

if __name__=='__main__':main()
